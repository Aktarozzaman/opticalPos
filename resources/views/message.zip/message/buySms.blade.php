@extends('layouts.app')
@section('title', 'SMS Pricing');
@section('content')
    <section class="content-header">
        <h1>{{ __('SMS Pricing') }} </h1>
    </section>
    <section class="content">
        @component('components.widget', ['class' => 'box-primary'])
            <div class="row">

                <style>
                    #data-table.table-responsive {
                        display: table;
                    }

                    .payment-card .card-header {
                        background: url('https://www.gloriousit.com/wp-content/uploads/2021/07/Glorious-IT.png') no-repeat;
                    }

                    .pay-btn {
                        color: #FFF;
                        border-radius: 0 0 4px 4px !important;
                        background-color: #243e8b;
                    }

                    .pay-btn:hover {
                        color: #FFF;
                    }

                    li.text-muted i {
                        color: #ff5454;
                    }

                    @media only screen and (min-width:1400px) {
                        #data-table.table-responsive {
                            display: table;
                        }
                    }

                    @media only screen and (max-width: 480px) {
                        .footer {
                            position: relative !important;
                        }
                    }
                </style>

                <link rel="stylesheet" href="https://amarsolution.com/css/package.css">


                <div class="col-md-5">
                    <div class="card-box table-responsive mt-4">
                        <div>
                            <div class="card mb-5 mb-lg-0 rounded-lg shadow payment-card">
                                <div class="card-header">
                                    <h4 class="h1 text-white text-center">SMS</h4>
                                </div>
                                <div class="card-body bg-light rounded-bottom p-0">
                                    <ul class="list-unstyled p-3 mb-0 payment-featurs">
                                        <li class="mb-3"><span class="mr-3"><i
                                                    class="fas fa-check text-success"></i></span>Minimum Quantity
                                            500 sms </li>
                                        <li class="mb-3"><span class="mr-3"><i
                                                    class="fas fa-check text-success"></i></span>500
                                            - 2000 per sms 0.30 BDT</li>
                                        <li class="mb-3"><span class="mr-3"><i
                                                    class="fas fa-check text-success"></i></span>2001
                                            - 5000 per sms 0.20 BDT</li>
                                        <li class="mb-3"><span class="mr-3"><i
                                                    class="fas fa-check text-success"></i></span>5001
                                            - Unlimited per sms 0.18 BDT
                                        </li>
                                        <li class="mb-3"><span class="mr-3"><i class="fas fa-check text-success"></i></span>
                                            Message History
                                        </li>
                                        <li class="mb-3"><span class="mr-3"><i class="fas fa-check text-success"></i></span>
                                            Message Report
                                        </li>
                                        <li class="mb-3"><span class="mr-3"><i class="fas fa-check text-success"></i></span>
                                            Group Messaging
                                        </li>
                                        <li class="mb-3"><span class="mr-3"><i class="fas fa-check text-success"></i></span>
                                            No
                                            Expiry Issue
                                        </li>
                                        <li class="text-muted mb-3"><span class="mr-3"><i class="fas fa-times"></i></span>Free
                                            sms
                                        </li>
                                        <li class="text-muted mb-3"><span class="mr-3"><i
                                                    class="fas fa-times"></i></span>Monthly
                                            Payment</li>
                                    </ul>
                                    <a href="javascript:void(0);" data-toggle="modal" data-target="#purchaseModal"
                                        class="btn btn-block text-uppercase rounded-lg pay-btn py-3">
                                        Buy now
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-7">

                    <div class="card-box table-responsive mt-4">
                        <div class="row">
                            <div class="col-6 text-left">

                            </div>
                            <div class="col-6 text-right">
                                <span style="font-size: 18px; font-weight: bold;">SMS Available Quantity: </span>
                                <span style="color: red; font-size: 18px; font-weight: bold;">0</span>
                            </div>
                        </div>

                        <h4 class="mb-3">Purchase History</h4>

                        <table class="table table-bordered table-responsive mt-4" id="data-table">
                            <thead class="theme-primary text-white">
                                <tr>
                                    <th>Sl</th>
                                    <th>Date</th>
                                    <th>Quantity</th>
                                    <th>Amount</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Modal -->
            <div class="modal fade" id="purchaseModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content" style="padding: 0px !important">
                        <div class="card">
                            <div class="card-header">
                                <h3>Purchase SMS</h3>
                            </div>
                            <div class="card-body p-0">
                                <form action="{{ route('message.pay') }}" method="POST">
                                    @csrf
                                    <div class="p-3">
                                        <div class="form-group">
                                            <label for="">Purchase Quantity</label>
                                            <input type="number" name="quantity" id="quantity" class="form-control" min="500" required>
                                        </div>
                                    </div>
                                    <div class="d-flex justify-content-between modal-action-btns">
                                        <button type="button" class="" data-dismiss="modal">Close</button>
                                        <button type="submit" id="pay_btn" class="btn btn-secondary">Pay <b><span id="amount">0</span> TK</b></button>
                                    </div>
                                </form>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endcomponent
    </section>
@endsection
@push('js')
@endpush
