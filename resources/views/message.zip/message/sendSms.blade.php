@extends('layouts.app')
@section('title', 'notifications');
@section('content')
    <section class="content-header">
        <h1>{{ __('Send SMS') }} </h1>
    </section>
    <section class="content">
        @component('components.widget', ['class' => 'box-primary'])
            <div class="row" <div class="col-md-6" style="background-color: #9fc5b4; padding: 20px;}">

                <div class="col-md-6">
                    <h4>Message Send</h4>
                    <form action="{{ route('sms.singleSMSSend') }}" method="post">
                        @csrf


                        {{-- <div class="col-md-12">
                            <div class="form-group">
                                <label>Select User Type<span class="text-danger" id="spanhide"> *</span></label>
                                <select class="form-control user_type" name="user_type" id="user_type">
                                    <option value="">{{ __('Select Customer/Vendor') }}</option>
                                    <option value="customer">{{ __('Customer') }}</option>
                                    <option value="supplier">{{ __('Supplier') }}</option>
                                </select>
                            </div>
                        </div> --}}


                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Mobile</label>
                                <select class="form-control user_type select2" multiple name="mobile_number[]" id="user_type">
                                    <option value="">{{ __('Select Number') }}</option>
                                    @foreach ($contacts as $contactInfo)
                                        <option value="{{ $contactInfo->mobile }}">
                                            {{ $contactInfo->name }}-{{ $contactInfo->mobile }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>


                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Select form Template message(optional)</label>
                                <select class="form-control temp_message_id" name="temp_message_id" id="temp_message_id">
                                    <option value="">{{ __('Select message') }}</option>
                                    @foreach ($template as $templateInfo)
                                        <option value="{{ $templateInfo->id }}">{{ $templateInfo->title_template }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>


                        <div class="col-md-6">
                            <label>Message <span class="text-danger"> *</span></label><br>
                            <textarea rows="5" cols="90" name="message" id="message" class="form-control templatesms" required
                                placeholder="Write message" autofocus></textarea>
                        </div>
                        <div class="col-md-6" style="margin-top: 24px;">
                            @component('components.widget', ['class' => 'box-primary'])
                                <div class="row">
                                    <div class="col-md-12" style="min-height: 90px;">
                                        <div id="the-count" style="margin-top: 15px;">
                                            <span id="current" style="color: green;font-weight: bolder;">Character count :
                                                0</span><br>
                                            <span id="messages" style="color: red;font-weight: bolder;">SMS count : 0</span><br>
                                            <span id="remaining" style="color: green;font-weight: bolder;">Characters remaining :
                                                160</span>
                                        </div>
                                    </div>
                                </div>
                            @endcomponent
                        </div>

                        {{-- <div class="col-md-6">
                            <div class="form-group">
                                <label>SMS Status <span class="text-danger">*</span></label><br>
                                <label for="send_sms_now">
                                    <input type="radio" class="send_sms_now" name="sms_status" value="send_sms_now"
                                        id="send_sms_now" checked>
                                    <small>Send now</small></label>
                                <label for="save_draft">
                                    <input type="radio" class="save_draft" name="sms_status" value="save_draft" id="save_draft">
                                    <small>Save draft</small></label>
                            </div>
                        </div> --}}


                        <div class="col-md-6 text-right">
                            <button type="submit" class="btn btn-primary" style="margin-top: 5px;">Send</button>
                        </div>
                    </form>
                </div>
                <div class="col-md-6">
                    <h4>Group Message Send</h4>

                    <form action="{{ route('sms.groupSMSSend') }}" method="post">
                        @csrf

                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Select User Type<span class="text-danger" id="spanhide"> *</span></label>
                                <select class="form-control user_type" name="group_user_type" id="user_type">
                                    <option value="">{{ __('Select') }}</option>
                                    <option value="all_customer">{{ __('all customer') }}</option>
                                    <option value="all_supplier">{{ __('all supplier') }}</option>
                                    <option value="due_customer">{{ __('Due customer') }}</option>
                                    {{-- <option value="due__supplier">{{ __('Due supplier') }}</option>s --}}

                                    @foreach ($groups as $groupsInfo)
                                        <option value="{{ $groupsInfo->id }}">{{ $groupsInfo->group_name }}</option>
                                    @endforeach

                                </select>
                            </div>
                        </div>


                        {{-- <div class="col-md-12">
                            <div class="form-group">
                                <label>Mobile</label>
                                <select class="form-control user_type select2" multiple name="mobile_number[]" id="user_type">
                                    <option value="">{{ __('Select Number') }}</option>
                                    @foreach ($contacts as $contactInfo)
                                        <option value="{{ $contactInfo->mobile }}">{{ $contactInfo->name }}-{{ $contactInfo->mobile }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div> --}}


                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Select form Template message(optional)</label>
                                <select class="form-control temp_message_id_ggroup" name="temp_message_id_ggroup"
                                    id="temp_message_id_ggroup">
                                    <option value="">{{ __('Select message') }}</option>
                                    @foreach ($template as $templateInfo)
                                        <option value="{{ $templateInfo->id }}">{{ $templateInfo->title_template }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <label>Message <span class="text-danger"> *</span></label><br>
                            <textarea rows="5" cols="90" name="message" id="groupmessage" class="form-control templategroupsms" required
                                placeholder="Write message" autofocus></textarea>
                        </div>
                        <div class="col-md-6" style="margin-top: 24px;">
                            @component('components.widget', ['class' => 'box-primary'])
                                <div class="row">
                                    <div class="col-md-12" style="min-height: 90px;">
                                        <div id="group-the-count" style="margin-top: 15px;">
                                            <span id="groupcurrent" style="color: green;font-weight: bolder;">Character count :
                                                0</span><br>
                                            <span id="groupmessages" style="color: red;font-weight: bolder;">SMS count :
                                                0</span><br>
                                            <span id="groupremaining" style="color: green;font-weight: bolder;">Characters remaining
                                                :
                                                160</span>
                                        </div>
                                    </div>
                                </div>
                            @endcomponent
                        </div>

                        {{-- <div class="col-md-6">
                            <div class="form-group">
                                <label>SMS Status <span class="text-danger">*</span></label><br>
                                <label for="send_sms_now">
                                    <input type="radio" class="send_sms_now" name="sms_status" value="send_sms_now"
                                        id="send_sms_now" checked>
                                    <small>Send now</small></label>
                                <label for="save_draft">
                                    <input type="radio" class="save_draft" name="sms_status" value="save_draft" id="save_draft">
                                    <small>Save draft</small></label>
                            </div>
                        </div> --}}


                        <div class="col-md-6 text-right">
                            <button type="submit" class="btn btn-primary" style="margin-top: 5px;">Send</button>
                        </div>
                    </form>

                </div>


            </div>
        @endcomponent
    </section>
@endsection
@push('js')
    <script>
        $('textarea').on('keyup click', function() {

            var characterCount = $(this).val().length,
                current = $('#current'),
                maximum = $('#maximum'),
                theCount = $('#the-count');

            current.text('Character count : ' + characterCount);
        });
    </script>


    <script>
        $('.templategroupsms').on('keyup click', function() {

            var groupcharacterCount = $(this).val().length,
                current = $('#groupcurrent'),
                maximum = $('#maximum'),
                theCount = $('#group-the-count');

            groupcurrent.text('Character count : ' + groupcharacterCount);
        });
    </script>



    <script>
        var $groupremaining = $('#groupremaining'),
            $groupmessages = $groupremaining.next();

        $('#groupmessage').on('keyup click', function() {
            var chars = this.value.length,
                groupmessages = Math.ceil(chars / 160),
                groupremaining = groupmessages * 160 - (chars % (groupmessages * 160) || groupmessages * 160);

            $('#groupremaining').text('Characters groupremaining : ' + groupremaining);
            $('#groupmessages').text('SMS Count : ' + groupmessages);
        });
    </script>


    <script>
        var $remaining = $('#remaining'),
            $messages = $remaining.next();

        $('#message').on('keyup click', function() {
            var chars = this.value.length,
                messages = Math.ceil(chars / 160),
                remaining = messages * 160 - (chars % (messages * 160) || messages * 160);

            $('#remaining').text('Characters remaining : ' + remaining);
            $('#messages').text('SMS Count : ' + messages);
        });
    </script>


    <script>
        $('#temp_message_id').on('change', function() {
            var tid = $(this).val();

            $.ajax({
                type: "GET",
                url: "{{ url('message/get-message-details') }}/" + tid,
                data: {
                    'tid': tid
                },
                success: function(data) {
                    $('.templatesms').val(data.template_message);
                }
            })
        });


        $('#temp_message_id_ggroup').on('change', function() {
            var tid = $(this).val();

            $.ajax({
                type: "GET",
                url: "{{ url('message/get-message-details') }}/" + tid,
                data: {
                    'tid': tid
                },
                success: function(data) {
                    $('.templategroupsms').val(data.template_message);
                }
            })
        });



        $('#user_type').attr('required', 'required');
        $('#send_sms_now').on('click', function() {
            $('#user_type').attr('required', 'required');
            $('#spanhide').show();
        });
        $('#save_draft').on('click', function() {
            $('#user_type').removeAttr('required', 'required');
            $('#spanhide').hide();
        });
    </script>
@endpush
