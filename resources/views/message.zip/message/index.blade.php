@extends('layouts.app')
@section('title', 'Message Setting');
@section('content')
    <section class="content-header">
        <h1>{{ __('Message Setting') }} </h1>
    </section>
    <section class="content">
        @component('components.widget', ['class' => 'box-primary'])
            <div class="row">
                <!-- Start content -->
                <div class="col-md-12">
                    <div class="card-box table-responsive mt-3">
                        <h4 class="mb-3">Message Setting</h4>

                        <div class="row my-3">
                            <div class="col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                <div class="small-box bg-primary whitecolor mt-3">
                                    <div class="inner">
                                        <h4><span class="count-number">10</span> </h4>
                                        <p>Total Purchase SMS</p>
                                    </div>
                                    <div class="icon">
                                        <i class="fa fa-sms"></i>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                <div class="small-box bg-darkgreen whitecolor mt-3">
                                    <div class="inner">
                                        <h4><span class="count-number">10</span> </h4>
                                        <p>Total Use SMS</p>
                                    </div>
                                    <div class="icon">
                                        <i class="fa fa-sms"></i>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                <div class="small-box bg-success whitecolor mt-3">
                                    <div class="inner">
                                        <h4><span class="count-number">0</span> </h4>
                                        <p>Total Available SMS</p>
                                    </div>
                                    <div class="icon">
                                        <i class="fa fa-sms"></i>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <table class="table table-bordered">
                                    <tr>
                                        <th>Sale</th>
                                        <th>
                                            <div class="switchery-demo">
                                                <input type="checkbox" value="1" id="enable_sale"
                                                    onchange="updateSetting('enable_sale')" checked data-plugin="switchery"
                                                    data-color="#00b19d" />
                                            </div>
                                        </th>
                                    </tr>

                                    <tr>
                                        <th>Sale Return</th>
                                        <th>
                                            <div class="switchery-demo">
                                                <input type="checkbox" value="1" id="enable_sale_return"
                                                    onchange="updateSetting('enable_sale_return')" checked
                                                    data-plugin="switchery" data-color="#00b19d" />
                                            </div>
                                        </th>
                                    </tr>

                                    <tr>
                                        <th>Sale Replace</th>
                                        <th>
                                            <div class="switchery-demo">
                                                <input type="checkbox" value="1" id="enable_sale_replace"
                                                    onchange="updateSetting('enable_sale_replace')" checked
                                                    data-plugin="switchery" data-color="#00b19d" />
                                            </div>
                                        </th>
                                    </tr>

                                    <tr>
                                        <th>Due Receive</th>
                                        <th>
                                            <div class="switchery-demo">
                                                <input type="checkbox" value="1" id="enable_due_receive"
                                                    onchange="updateSetting('enable_due_receive')" checked
                                                    data-plugin="switchery" data-color="#00b19d" />
                                            </div>
                                        </th>
                                    </tr>

                                    <tr>
                                        <th>Due Payment</th>
                                        <th>
                                            <div class="switchery-demo">
                                                <input type="checkbox" value="1" id="enable_due_payment"
                                                    onchange="updateSetting('enable_due_payment')" checked
                                                    data-plugin="switchery" data-color="#00b19d" />
                                            </div>
                                        </th>
                                    </tr>

                                    <tr>
                                        <th>Installment</th>
                                        <th>
                                            <div class="switchery-demo">
                                                <input type="checkbox" value="1" id="enable_installment"
                                                    onchange="updateSetting('enable_installment')" checked
                                                    data-plugin="switchery" data-color="#00b19d" />
                                            </div>
                                        </th>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endcomponent
    </section>
@endsection
@push('js')
@endpush
